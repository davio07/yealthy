<?php 
/* Cachekey: cache/stash_default/translation/js/en/ */
/* Type: array */
/* Expiration: 2019-09-15T15:41:42-04:00 */



$loaded = true;
$expiration = 1568576502;

$data = array();

/* Child Type: string */
$data['return'] = "Mibew.Localization.set({\"Login\":\"Login\",\"Mibew Messenger\":\"Mibew Messenger\",\"Mibew Messenger is an open-source live support application.\":\"Mibew Messenger is an open-source live support application.\",\"Please enter your username and password to access administrative tools. See your visitors and browse the history.\":\"Please enter your username and password to access administrative tools. See your visitors and browse the history.\",\"Login:\":\"Login:\",\"Password:\":\"Password:\",\"Remember\":\"Remember\",\"Enter\":\"Enter\",\"Forgot your password?\":\"Forgot your password?\"});";

/* Child Type: integer */
$data['createdOn'] = 1568181836;
